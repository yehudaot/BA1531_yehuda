#ifndef VERSION_H_
#define VERSION_H_

#define VERSION_DAY 19
#define VERSION_MONTH 12
#define VERSION_YEAR 2017
#define VERSION_MAJOR 1
#define VERSION_MINOR 9

#endif /* VERSION_H_ */
