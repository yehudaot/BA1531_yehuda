#ifndef __CRC8__
#define __CRC8__

#include <stdint.h>

uint8_t crc8(uint8_t* buffer, uint16_t size);

#endif
